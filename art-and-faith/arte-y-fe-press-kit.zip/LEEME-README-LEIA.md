# Arte y Fe · Art & Faith · Arte e Fé — Kit de prensa / Press kit / Kit de imprensa

Clajorix Games · Publicado en Google Play el 9 de agosto de 2026

---

## Español

**Título:** Arte y Fe: Puzzles Bíblicos
**Estudio:** Clajorix Games (desarrollador independiente)
**Plataforma:** Android (Google Play) — `com.clajorix.bibliapuzzle`
**Precio:** gratis, con compras opcionales (Sin Anuncios US$2,99 · Edición Completa US$4,99)
**Idiomas:** español, inglés y portugués
**Enlace:** https://play.google.com/store/apps/details?id=com.clajorix.bibliapuzzle

Arte y Fe une el arte clásico con la Palabra: 300 puzzles de pinturas y grabados
en dominio público, organizados en 15 colecciones que recorren la Biblia de
Génesis a Apocalipsis. Al completar cada obra se descubre el versículo que la
inspiró y la historia detrás de la escena. Incluye un devocional diario con 186
salmos, un modo maestro con tableros grandes y una galería donde las obras
desbloqueadas se pueden leer con calma y guardar en el teléfono.

Está pensada sin cronómetros ni presión de ningún tipo. Es un proyecto devocional
independiente, sin afiliación a ninguna iglesia ni denominación.

## English

**Title:** Art & Faith: Bible Puzzles
**Studio:** Clajorix Games (independent developer)
**Platform:** Android (Google Play) — `com.clajorix.bibliapuzzle`
**Price:** free, with optional purchases (No Ads US$2.99 · Full Edition US$4.99)
**Languages:** English, Spanish and Portuguese
**Link:** https://play.google.com/store/apps/details?id=com.clajorix.bibliapuzzle

Art & Faith brings together classical art and Scripture: 300 puzzles of
public-domain paintings and engravings, organised into 15 collections that walk
through the Bible from Genesis to Revelation. Completing an artwork reveals the
verse that inspired it and the story behind the scene. It includes a daily
devotional built on 186 psalms, a master mode with larger boards, and a gallery
where unlocked artworks can be read at leisure and saved to the phone.

It was built without timers or pressure of any kind. It is an independent
devotional project, with no affiliation to any church or denomination.

## Português

**Título:** Arte e Fé: Quebra-Cabeças
**Estúdio:** Clajorix Games (desenvolvedor independente)
**Plataforma:** Android (Google Play) — `com.clajorix.bibliapuzzle`
**Preço:** grátis, com compras opcionais (Sem Anúncios US$2,99 · Edição Completa US$4,99)
**Idiomas:** português, espanhol e inglês
**Link:** https://play.google.com/store/apps/details?id=com.clajorix.bibliapuzzle

Arte e Fé une a arte clássica à Palavra: 300 quebra-cabeças de pinturas e
gravuras em domínio público, organizados em 15 coleções que percorrem a Bíblia de
Gênesis a Apocalipse. Ao completar cada obra, aparece o versículo que a inspirou e
a história por trás da cena. Inclui um devocional diário com 186 salmos, um modo
mestre com tabuleiros maiores e uma galeria onde as obras desbloqueadas podem ser
lidas com calma e salvas no telefone.

Foi feito sem cronômetros nem pressão de nenhum tipo. É um projeto devocional
independente, sem vínculo com nenhuma igreja ou denominação.

---

## Sobre las obras / About the artworks / Sobre as obras

Todas las imágenes del juego son reproducciones de obra en **dominio público**
—principalmente grabados de Gustave Doré y láminas de Julius Schnorr von
Carolsfeld—, acreditadas dentro de la app con su autor, su título y su licencia.
Los textos bíblicos usan traducciones también en dominio público: Reina-Valera
(es), King James Version (en) y Almeida (pt).

## Contenido de este kit / What's inside / Conteúdo

- `icon-512.png` — icono de la app, 512×512
- `feature-graphic*.png` — gráfico de portada de Google Play (es / en / pt), y las
  versiones en 4K
- `screenshots/` — cinco capturas por idioma (es / en / pt): inicio, puzzle,
  devocional diario, galería y ficha de obra

## Uso / Usage / Uso

Estos materiales se pueden reproducir libremente en artículos, reseñas y notas
sobre el juego. Las capturas e imágenes de portada no deben recortarse de forma
que se pierdan los créditos de las obras.

## Contacto / Contact / Contato

clajorixgames@gmail.com — con gusto enviamos códigos de la Edición Completa para
reseñar y para sortear entre lectores.
